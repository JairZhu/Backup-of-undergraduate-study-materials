
A mini-Demo of SSL handshake using std openssl library

depend on
	../include/std    when compile
	../lib/std        when link
	../certs/*.pem
	its DLLs          when run

ref to readme.doc

last ok time
	OpenSSL-0.9.6g	 
	14:17 2002-10-3