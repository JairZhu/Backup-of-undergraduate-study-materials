// ddes.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#if 0
int _tmain(int argc, _TCHAR* argv[])
{
	return 0;
}
#endif

#include <stdio.h>
#include <time.h>
#include <openssl/sha.h>
#include <openssl/des.h>


char *version = "demo of des v0.1-naive, 1:43 2003-3-13, by Linden";

main()
{
	char passwd[10] = "passwd"; // 10 asciis emough
	unsigned char salt[16];		// hoho
	unsigned char md[20];		// message digest of passwd+salt
	unsigned char iv[8];		// initial vector
	unsigned char key[8];		// 56+8 bits

	unsigned char plaintext[100] = "the plain text";
	unsigned char ciphertext[100] = "null1";
	unsigned char plaintext2[100] = "null2";  // ���ܺ�õ�������

#if 0
	{	// ECB mode
		DES_key_schedule sch;
		DES_cblock k;
		memcpy(&k, "password", 8);
		DES_set_key_unchecked(&k, &sch);
		DES_ecb_encrypt((const_DES_cblock *)"plaintxt",
			(DES_cblock *)ciphertext,
			&sch, DES_ENCRYPT);

		memcpy(&k, "password", 8);
		DES_set_key_unchecked(&k, &sch);
		DES_ecb_encrypt((DES_cblock *)ciphertext,
			(DES_cblock *)plaintext2,
			&sch, DES_DECRYPT);
		if (strncmp("plaintxt", (const char*)plaintext2, 8)==0)
			puts("ok");
		else
			puts("bad");
		exit(-2);
	}
#endif


	puts("passwd?");
	//gets(passwd);				// give a password
	*((time_t*)salt) = time(0);	// time as salt

	// get md
	{	SHA_CTX c;
		SHA1_Init(&c);
		SHA1_Update(&c, passwd, strlen(passwd));
		SHA1_Update(&c, salt, sizeof(time_t));
		SHA1_Final(md, &c);
	}
	
	// 8B iv + 8B key
	memcpy(iv, md, 8);
	memcpy(key, md+8, 8);

	// destory !
	memset(passwd, 0, sizeof(passwd));
	memset(salt, 0, sizeof(salt));
	memset(md, 0, sizeof(md));
	
	{	//enc
		DES_key_schedule sch;
		DES_cblock k;
		DES_cblock i;
		memcpy(k, key, 8);
		memcpy(i, iv, 8);
		
		//DES_set_key(&k, &sch);
		DES_set_key_unchecked(&k, &sch);
		DES_cfb_encrypt(plaintext, ciphertext,
			//strlen((const char*)plaintext)*
			8,
			strlen((const char*)plaintext),
			&sch, &i,
			DES_ENCRYPT);

        memset(k, 0, sizeof(k));
		memset(&sch, 0, sizeof(sch));
		memset(&i, 0, sizeof(i));
	}

	{	//dec
		DES_key_schedule sch;
		DES_cblock k;
		DES_cblock i;
		memcpy(k, key, 8);
		memcpy(i, iv, 8);

		//DES_set_key(&k, &sch);
		DES_set_key_unchecked(&k, &sch);
		DES_cfb_encrypt(ciphertext, plaintext2,
			//strlen((const char*)plaintext)*
			8,
			strlen((const char*)plaintext), // the same as input
			&sch, &i,
			DES_DECRYPT);

        memset(k, 0, sizeof(k));
		memset(&sch, 0, sizeof(sch));
		memset(&i, 0, sizeof(i));
	}

	{	// compare text and text2

		puts("DES-CFB8 test result");
		if (strcmp((const char*)plaintext, (const char*)plaintext2)==0)
		{
			puts("  enc/dec ok");
		}
		else
		{
			puts("  enc/dec err");
		}
	}

	{
		memset(key, 0, sizeof(key));
		memset(iv, 0, sizeof(iv));
		memset(plaintext, 0, sizeof(plaintext));
		memset(ciphertext, 0, sizeof(ciphertext));
		memset(plaintext2, 0, sizeof(plaintext2));
	}
}


