
#include "sslt.c"

// no argument needed
int main(int argc, char *argv[])
{
	int err = 0;

	do
	{
		/* a once loop */
		
		SSL_METHOD* meth;
		SSL_CTX* ctx;
		SSL* ssl;

		/* random number seed
		{	char buf[1000];
			RAND_add(buf, 1000, 1000.0);
			// enough for a demo, but not for a product
		} */

		/* initialize */
		SSL_load_error_strings();
		OpenSSL_add_all_algorithms();

		/* SSL v2, v3, v23 or TLS v1 */
		meth = SSLv3_server_method();
		if (!meth)
		{	err = -10;
			break;
		}

		/* SSL context */
		ctx = SSL_CTX_new(meth);
		if (!ctx)
		{	err = -20;
			break;
		}
		
		/* ciphers */
		if (!SSL_CTX_set_cipher_list(ctx, CIPHERS))
		{	err = -30;
			break;		
		}
		
		/* certificate */
		if (!SSL_CTX_use_certificate_file(ctx, SERVER_CERT, X509_FILETYPE_PEM))
		{	err = -40;
			break;		
		}
		/* private key */
		if (!SSL_CTX_use_PrivateKey_file(ctx, SERVER_CERT, X509_FILETYPE_PEM))
		{	err = -50;
			break;		
		}

		/* check for consistent */
		if (!SSL_CTX_check_private_key(ctx))
		{	err = -60;
			break;		
		}

		/* CA  */
		if (!SSL_CTX_load_verify_locations(ctx, CA_CERT, NULL))
		{	err = -70;
			break;
		}

		/* about authentication/authorization */
		SSL_CTX_set_verify(ctx,
			SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT, NULL);
		/* if anonymous, change to SSL_VERIFY_NONE */

		/* being a server */
		printf("wait on [%s:%1d]...\n", DEFAULT_SSL_HOST_EXT, DEFAULT_SSL_PORT);
		while (1)
		{
			int err = 0;
			SOCKET anews;
			
			anews = wait_connect(DEFAULT_SSL_HOST_EXT, DEFAULT_SSL_PORT);
			if (!anews)
			{	err = -80;
				break;		
			}

			putchar('+');

			ssl = SSL_new(ctx);

			SSL_set_fd(ssl, anews);

			err = SSL_accept(ssl);
			err = SSL_get_error(ssl, err);
			
			switch (err)
			{
				case SSL_ERROR_NONE:
					break;

				case SSL_ERROR_WANT_WRITE:
				case SSL_ERROR_WANT_READ:
				case SSL_ERROR_WANT_X509_LOOKUP:
					break;

				case SSL_ERROR_SYSCALL: 				
				case SSL_ERROR_SSL:
				case SSL_ERROR_ZERO_RETURN:
					err = -10010;
					break;

				default:
					err = -10020;
					break;
			}
			
			if (err)
			{
				printf("handshake error %1d ", err);
				ERR_print_errors_fp(stdout);
			}
			else
			{
				unsigned char buffer[64*1024];
				while (1)
				{
					int i, e;
					i = SSL_read(ssl, buffer, sizeof(buffer));
					e = SSL_get_error(ssl, i);
					if (e == SSL_ERROR_NONE)
					{
						i = SSL_write(ssl, buffer, i);
						e = SSL_get_error(ssl, i);
						if (e != SSL_ERROR_NONE)
							break;
					}
					else
						break;
					putchar('#');  puts("==========");
				}
			}

			SSL_free(ssl);
			closesocket(anews);
			putchar('-');
		} /* while 1 */


	} while (0);

	if (err)
	{
		printf("error %1d\n", err);
		return -1;
	}
	
	printf("Never reach\n");


	return 0;
}

