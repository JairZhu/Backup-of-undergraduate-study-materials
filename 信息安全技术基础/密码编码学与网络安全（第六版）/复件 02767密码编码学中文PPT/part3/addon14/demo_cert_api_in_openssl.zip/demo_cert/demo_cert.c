
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <openssl/pem.h>
#include <openssl/x509.h>

#define root_cert  "cacert.pem"   // '1
#define user_cert  "u1.pem"       // '2

main()
{
	BIO *fcert1, *fcert2;
	X509 *x1, *x2;
	EVP_PKEY *k1, *k2;

	SSL_load_error_strings(); /* readable error messages */
	SSL_library_init();  

	fcert1 = BIO_new(BIO_s_file());
	fcert2 = BIO_new(BIO_s_file());
	BIO_read_filename(fcert1, root_cert);
	BIO_read_filename(fcert2, user_cert);

	x1 = PEM_read_bio_X509_AUX(fcert1, NULL, NULL, NULL);
	x2 = PEM_read_bio_X509_AUX(fcert2, NULL, NULL, NULL);
	
#define show_hehe(x)							\
	printf("ver = %d\n", X509_get_version(x));	\
												\
	puts("issuer:");							\
	{	char buf[1000];							\
		X509_NAME *a = X509_get_issuer_name(x);	\
		X509_NAME_oneline(a, buf, 1000);		\
		puts(buf);								\
	}											\
												\
	puts("subject:");							\
	{	char buf[1000];							\
		X509_NAME *a = X509_get_subject_name(x);\
		X509_NAME_oneline(a, buf, 1000);		\
		puts(buf);								\
	}											

	show_hehe(x1);
	show_hehe(x2);
	k1 = X509_get_pubkey(x1);
	k2 = X509_get_pubkey(x2);

#if 0 // ��һ���ֻ��д��󣬿�����˼·���ԣ�����Ϊ��ϰ��֮��
	  // ����ok�ˡ�
	ret = X509_verify(x1, k1);	// ����1

	ret = X509_verify(x2, k1);	// 1

	ret = X509_verify(x1, k2);	// 0

	ret = X509_verify(x2, k2);  // 0

#endif

	if (X509_verify(x1, k1)>0) // ����1
		if (X509_verify(x2, k1))	// 1
			puts("all ok");
	// ��˵������û�(user_cert)��֤��
	//   ȷʵ���������(root_cert)ǩ����

	return 0;
}