
// demo how to enc a piece of data using RSA
//  by Linden 0:23 2003-11-15

#include <openssl/md5.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <string.h>

main()
{
	#define RSA_KEY_FILE "rsakey.txt"
		// > openssl genrsa -out rsakey.txt 1024
	RSA* key;
	char msg[]="i, i have no data to enc";
	char msg2[256];
	char msg3[256];
	int r;
	
	//SSL_library_init();
	//SSL_load_error_strings();
	//OpenSSL_add_all_algorithms();

	key = RSA_new();

#if 1	// gen 
	puts("genrsa...(maybe a few seconds)");
	key = RSA_generate_key(1024, 65537, NULL, NULL);
	puts("ok");
#else	// read in
	{FILE *fp = fopen(RSA_KEY_FILE, "r");
	 key = PEM_read_RSAPrivateKey(fp, &key, NULL, NULL);
	}
#endif

#if 1	// display
	{BIO *o = BIO_new_fd(fileno(stdout), BIO_NOCLOSE);
	 RSA_print(o, key, 0);
	}
#endif


	r = RSA_public_encrypt(strlen(msg), msg, msg2, 
		key, RSA_PKCS1_PADDING); //  or RSA_PKCS1_OAEP_PADDING
	if (!r)
		puts("error in enc");

#if 0
	sig[0]++; // ����Ĵ���
#endif

	r = RSA_private_decrypt(r, msg2, msg3, 
		key, RSA_PKCS1_PADDING);
	if (!r)
		puts("error in dec");

	if (memcmp(msg, msg3, strlen(msg)))
		puts("ERROR! text2 != text");
	else
	{
		msg3[strlen(msg)] = 0;
		printf("���ܺ�����ģ�%s", msg3);
	}

	puts("is there errs? no? ok!");

	RSA_free(key);

	return 0;
}
