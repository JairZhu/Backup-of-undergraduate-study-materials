<html>

  <head>
	<h1> This is a poor web script, test.php</h1>
	<hr/>
  </head>

<body>

<?php

 
 
 print "<p>";


 $filen = $_POST['filename'];
 
 system("cat $filen");

 print "</p>";


?>

</body>
</html>

