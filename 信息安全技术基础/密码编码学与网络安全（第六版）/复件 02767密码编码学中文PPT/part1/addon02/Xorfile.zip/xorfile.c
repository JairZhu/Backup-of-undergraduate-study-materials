
// һ���򵥵���ʾ���������������
// by Linden 2001-12-2 14:30
// modified by Linden 11:18 2003-4-12


#include <stdio.h>
#include <stdlib.h>

#define buf_size (100*1024)

main(int argc, char* argv[])
{
	char* fname;
	FILE* file;
	char  xor=-1;
	int   len=-1;
	int   i, k;
	char* buf;
	int   max;

	if (argc<=1)
	{
	err_exit:
		puts("xorfile <fname> [0~255|256+](seed or length)");
		exit(1);
	}

	if (argc>=2)
		fname = argv[1];
	if (argc>=3)
	{
		if (sscanf(argv[2], "%d", &i) == 1)
		{
			if ((i>=0) && (i<=255))
				xor = i;
			else if (i>=256)
				len = i;
			else
				goto err_exit;
		}
		else
			goto err_exit;
	}

	file = fopen(fname, "r+b");
	if (file)
	{
		buf = malloc(buf_size);
		fseek(file, 0, SEEK_END);
		max = ftell(file);
		if (len==-1)
			len = max;
		else if (len>max)
			len = max;
		fseek(file, 0, SEEK_SET);
		
		while (len)
		{
			i = fread(buf, 1, len<buf_size?len:buf_size, file);
			if (i>0)
			{
				for (k=0; k<i; k++)
					buf[k] ^= xor;
				fseek(file, -i, SEEK_CUR);
				fwrite(buf, 1, i, file);
				len -= i;
			}
		}
		fclose(file);
		puts("file xor ok");
	}
	else
		puts("file open error");

	return 0;
}
