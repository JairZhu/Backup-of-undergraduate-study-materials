<html>

  <head>
	<h1> The results:</h1>
	<hr/>
  </head>

<body>

<?php

 
 
 print "<p>";
 $tool = $_POST['tool'];
 $tooldir = './products/' . $tool;

 print "<b>The files in the tool are:</b>";

 system("ls $tooldir");

 $filename = $_POST['filename'];
 
 $fullpath = './products/' . $tool .'/' . $filename;

 $cmd = 'cat ' . $fullpath; 
 system("cat $fullpath");

 print "</p>";


?>

<p>
<!--<b>NOTE:</b> If you are a student and can read this, you gained 10 extra points!!-->
</p>
<b>NOTE:</b> You are in the right direction. process.php was the script that was executed to print this page. You should now go back to the Products page, and enter commands separated by semi-colon (;) or pipeline (|). You will see that it works just like a shell. For example, test it by typing " ; date" and it will print today's date and time information. Type "; ls" to list the folders and files in the current directory. You should find a folder, PointsHere. Type " ; ls PointsHere" and you will find a points.htm file. The last step is to print the contents of this file on the screen. So type " ; cat PointsHere/points.htm" in the text box in the Products page and you will reach your destination. Good luck.
</body>
</html>

