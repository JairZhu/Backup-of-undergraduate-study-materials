
#include "sslt.c"


// no argument needed
int main(int argc, char *argv[])
{
	int err = 0;

	do	/* a once loop */
	{
		
		SSL_METHOD* meth;
		SSL_CTX* ctx;
		SSL* ssl;

		/* random number seed
		{	char buf[1000];
			RAND_add(buf, 1000, 1000.0);
			// enough for a demo, but not for a product
		} */

		/* initialize */
		SSL_load_error_strings();
		OpenSSL_add_all_algorithms();

		/* SSL v2, v3, v23 or TLS v1 */
		meth = SSLv3_client_method();
		if (!meth)
		{	err = -10;
			break;
		}

		/* SSL context */
		ctx = SSL_CTX_new(meth);
		if (!ctx)
		{	err = -20;
			break;
		}
		
		/* ciphers */
		if (!SSL_CTX_set_cipher_list(ctx, CIPHERS))
		{	err = -30;
			break;		
		}
		
		/* certificate */
		if (!SSL_CTX_use_certificate_file(ctx, CLIENT_CERT, X509_FILETYPE_PEM))
		{	err = -40;
			break;		
		}
		/* private key */
		if (!SSL_CTX_use_PrivateKey_file(ctx, CLIENT_CERT, X509_FILETYPE_PEM))
		{	err = -50;
			break;		
		}

		/* check for consistent */
		if (!SSL_CTX_check_private_key(ctx))
		{	err = -60;
			break;		
		}

		/* CA */ 
		if (!SSL_CTX_load_verify_locations(ctx, CA_CERT, NULL))
		{	err = -70;
			break;		
		}

		/* about authentication/authorization */
		SSL_CTX_set_verify(ctx,
			SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT, NULL);
		/* if anonymous, change to SSL_VERIFY_NONE */

		/* being a client */
		printf("try [%s:%1d]...\n", DEFAULT_SSL_HOST_LPBK, DEFAULT_SSL_PORT);
		while (1)
		{
			int ct = 999; /* easy for test */
			int err = 0;
			SOCKET a;

			while (ct--)
			{	a = active_connect(DEFAULT_SSL_HOST_LPBK, DEFAULT_SSL_PORT);
				if (a)
					break;
			}
			if (!a)
			{	err = -80;
				break;	
			}

			putchar('+');

			ssl = SSL_new(ctx);

			SSL_set_fd(ssl, a);

			err = SSL_connect(ssl);
			err = SSL_get_error(ssl, err);
			
			switch (err)
			{
				case SSL_ERROR_NONE:
					break;

				case SSL_ERROR_WANT_WRITE:
				case SSL_ERROR_WANT_READ:
				case SSL_ERROR_WANT_X509_LOOKUP:
					break;

				case SSL_ERROR_SYSCALL:					
				case SSL_ERROR_SSL:
				case SSL_ERROR_ZERO_RETURN:
					err = -10010;
					break;

				default:
					err = -10020;
					break;
			}
			
			if (!err)
			{
				unsigned char buffer[64*1024];
				do
				{
					int e, i = 999;
					i = SSL_write(ssl, buffer, i);
					e = SSL_get_error(ssl, i);
					if (e == SSL_ERROR_NONE)
					{
						i = SSL_read(ssl, buffer, sizeof(buffer));
						e = SSL_get_error(ssl, i);
						if (e != SSL_ERROR_NONE)
							break;
					}
					else
						break;
					putchar('*'); puts("----------");
					Sleep(10);
				}
				while (0);
			}
			else
			{	
				printf("handshake error %1d", err);				
			}

			SSL_free(ssl);
			closesocket(a);
			putchar('-');
			Sleep(10);
		}


	}
	while (1);

	if (err)
	{
		printf("error %1d\n", err);
		return -1;
	}
	
	puts("Never reach\n");


	return 0;
}

