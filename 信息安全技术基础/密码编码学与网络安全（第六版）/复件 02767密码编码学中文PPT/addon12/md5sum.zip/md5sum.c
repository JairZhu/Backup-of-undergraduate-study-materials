
#include <stdlib.h>
#include <stdio.h>
#include <openssl/md5.h>

main(int argc, char* argv[])
{
	MD5_CTX c;
	unsigned char md[MD5_DIGEST_LENGTH];

	FILE* fin=0;
	if (argc==2)
		fin = fopen(argv[1], "rb");
	if (!fin)
		fin=stdin;

	MD5_Init(&c);
	while (!feof(fin))
	{
		#define bsize 1024
		char buff[bsize];
		unsigned long len;
		len = fread(buff, 1, bsize, fin);		
		MD5_Update(&c, buff, len);
	}
	MD5_Final(md, &c);

	if (fin!=stdin)
		fclose(fin);

	{ int i;
	  for (i=0; i<MD5_DIGEST_LENGTH; i++)
		printf("%02x", md[i]);
	  printf("\n");
	}
	

	return 0;
}
