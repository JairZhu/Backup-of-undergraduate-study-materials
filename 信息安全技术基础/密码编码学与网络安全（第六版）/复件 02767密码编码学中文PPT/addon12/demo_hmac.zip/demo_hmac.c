
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>

main()
{
	char message[] = {"i wanna this message's digest"};
	unsigned char key[] = {0x12, 0x23, 0x34, 0x45,
						 0x56, 0x67, 0x78, 0x89,};
	unsigned char md[16+4];
	unsigned int md_len=sizeof(md), i;
	const EVP_MD *evp_md_md5 = EVP_md5();
	//const EVP_MD *evp_md_sha1 = EVP_sha1();

//#if 1
	{	// use HMAC in one step
	unsigned char *p = HMAC(evp_md_md5, key, sizeof(key),
		    message,
			(int)strlen(message),
			md, &md_len);

	printf("message: %s\n", message);
	printf("MD: (in MD5)\n    ");
	for (i=0; i<md_len; i++)
		printf(" %02x", md[i]);
	printf("\n\n");
	}
//#else
	{	// use several steps in detail
	HMAC_CTX ctx;
	
	HMAC_CTX_init(&ctx);
	HMAC_Init(&ctx, key, sizeof(key), evp_md_md5);
	HMAC_Update(&ctx, message, (int)strlen(message));
	HMAC_Final(&ctx, md, &md_len);
	HMAC_CTX_cleanup(&ctx);

	printf("message: %s\n", message);
	printf("MD: (in MD5)\n    ");
	for (i=0; i<md_len; i++)
		printf(" %02x", md[i]);
	printf("\n\n");
	}
//#endif

	return 0;
}