
#if false
using System;

namespace ConsoleApplication1
{
	/// <summary>
	/// Class1 ��ժҪ˵����
	/// </summary>
	class Class1
	{
		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: �ڴ˴����Ӵ���������Ӧ�ó���
			//
		}
	}
}
#endif

using System;
using System.IO;
using System.Security.Cryptography;

namespace MyCryptoW8BySeafrog
{
	class DES_AND_RC2
	{
		private static void CryptDataByDES(String inName, byte[] desKey, byte[] desIV, bool IsEncrypt)
		{//ʹ��DES����
			FileStream fin = new FileStream(inName, FileMode.Open, FileAccess.Read);
			FileStream fout = new FileStream(inName+".DES_BY_SEAFROG", FileMode.OpenOrCreate, FileAccess.Write);
			fout.SetLength(0);
   
			byte[] bin = new byte[100]; 
			long rdlen = 0;              
			long totlen = fin.Length;    
			int len;                    
 
			DES des = new DESCryptoServiceProvider();
			CryptoStream CStream;
			if(IsEncrypt)
			{
				CStream = new CryptoStream(fout, des.CreateEncryptor(desKey, desIV), CryptoStreamMode.Write);
				Console.WriteLine("Encrypting...");
			}
			else
			{
				CStream = new CryptoStream(fout, des.CreateDecryptor(desKey, desIV), CryptoStreamMode.Write);
				Console.WriteLine("Decrypting...");
			}

			while(rdlen < totlen)
			{
				len = fin.Read(bin, 0, 100);
				CStream.Write(bin, 0, len);
				rdlen = rdlen + len;
				Console.WriteLine("{0} bytes processed", rdlen);
			}
 
			CStream.Close();  
			fout.Close();
			fin.Close();                   
		}
		
		private static void CryptDataByRC2(String inName, byte[] desKey, byte[] desIV, bool IsEncrypt)
		{//ʹ�ãңã�����
			FileStream fin = new FileStream(inName, FileMode.Open, FileAccess.Read);
			FileStream fout = new FileStream(inName+".RC2_BY_SEAFROG", FileMode.OpenOrCreate, FileAccess.Write);
			fout.SetLength(0);
   
			byte[] bin = new byte[100]; 
			long rdlen = 0;              
			long totlen = fin.Length;    
			int len;                    
 
			RC2 rc2=new RC2CryptoServiceProvider();
			CryptoStream CStream;
			if(IsEncrypt)
			{
				CStream = new CryptoStream(fout, rc2.CreateEncryptor(desKey, desIV), CryptoStreamMode.Write);
				Console.WriteLine("Encrypting...");
			}
			else
			{
				CStream = new CryptoStream(fout, rc2.CreateDecryptor(desKey, desIV), CryptoStreamMode.Write);
				Console.WriteLine("Decrypting...");
			}

			while(rdlen < totlen)
			{
				len = fin.Read(bin, 0, 100);
				CStream.Write(bin, 0, len);
				rdlen = rdlen + len;
				Console.WriteLine("{0} bytes processed", rdlen);
			}
 
			CStream.Close();  
			fout.Close();
			fin.Close();                   
		}

		[STAThread]
		static void Main(string[] args)
		{
			Byte[] key=new byte[8]{0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef};
			Byte[] VI=new byte[8]{0x10,0x32,0x54,0x76,0x98,0xba,0xdc,0xfe};
			do
			{//��һ���ļ���ʹ�������������ܺ������ļ��е����ݽ��мӡ�����
				Console.WriteLine("Using DES or RC2?(D/R)");
				string IsDesStr=Console.ReadLine();
				Console.WriteLine("Encrypt or Decrypt a File? (E/D)");
				string IsEnStr=Console.ReadLine();
				Console.WriteLine("Please enter the plain file name:");
				string InFileStr=Console.ReadLine();
				
				if(IsDesStr.Equals("D")||IsDesStr.Equals("d"))
				{
					if(IsEnStr.Equals("E")||IsEnStr.Equals("e"))
						CryptDataByDES(InFileStr,key,VI,true);
					else
						CryptDataByDES(InFileStr,key,VI,false);
				}
				else
				{
					if(IsEnStr.Equals("E")||IsEnStr.Equals("e"))
						CryptDataByRC2(InFileStr,key,VI,true);
					else
						CryptDataByRC2(InFileStr,key,VI,false);
				}

				Console.WriteLine("Complete! Press q to quit. Or press any other key to continue.");
			}while(!Console.ReadLine().Equals("q"));
		}
	}
}    
