
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "rc4.h"


char *version = "rc4enc v0.2+naive 1:47 2003-3-13 by Linden";

int enc(char* buff, int len, char* buff2, int* len2)
{
	char passwd[16];
	RC4_KEY key;

	memset(passwd, 0, 16);
	puts("Pleasw input passwd:");
	gets(passwd);

	RC4_set_key(&key, 16, passwd);

	RC4(&key, len, buff, buff2);

	*len2 = len;

	return 0;
}

main(int argc, char* argv[])
{
	char* fname1;
	char  fname2[100];
	FILE *file1, *file2;
	char  buff1[10*1024];
	char  buff2[10*1024];
	int   len1, len2;

	if (argc!=2)
	{
		puts("usage: enc <filename>");
		return -1;
	}

	fname1 = argv[1];
	strcpy(fname2, fname1);
	strcat(fname2, ".enc");
	file1 = fopen(fname1, "rb");	
	file2 = fopen(fname2, "wb");

	while (1)
	{
		len1 = fread(buff1, 1, 10*1024, file1);
		if (len1<=0)
			break;
		
		enc(buff1, len1, buff2, &len2);
		
		fwrite(buff2, 1, len2, file2);
	}

	fclose(file1);
	fclose(file2);
}

