
// des.c

//
// des.h DES encrpt header file
// by linfb@sdu.edu.cn
//  2003-12-25
//

#include "des.h"

