
#include "des.c"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define priKey_bits		(56+8)	// 56 bits outof 64 bits
#define priKey_bytes	((priKey_bits)/8)
#define subKey_bits		(48)    // subkey has 48 bits
#define subKey_bytes	((subKey_bits)/8)

#define aBlock_bits		64		// a block has 64 bits
#define aBlock_bytes	((aBlock_bits)/8)

#define Rounds			16

#define ENC 0	// encypt
#define DEC 1   // decrypt

typedef unsigned char ABlock[aBlock_bytes]; // 8B
typedef unsigned char priKey[priKey_bytes]; // 56bits outof 8bytes
typedef unsigned char subKey[subKey_bytes]; // 46b out of 8B
typedef	unsigned char subKeyring[Rounds][subKey_bytes]; // 6B * 16

typedef struct {
	int ready;
	priKey pk; // 8B
	subKeyring skr; // 6B*16
} DES_Context;

// Permuted Choice 1
int des_pc1(priKey* pk)
{
	//
	return 0;
}

// Permuted Choice 2
int des_pc2(priKey* pk, subKey* skr)
{
	//
	return 0;
}

// 56bit=28b*2, left shift (b)bits
int lshift(priKey* pk, int b)
{
	//
	return 0;
}

int des_gen_subkeyring(priKey* pk, subKeyring* skr)
{
	int i;
	int b[Rounds] = {1,1,2,2,2,2,2,2,  1,2,2,2,2,2,2,1};

	des_pc1(pk);
	
	for (i=0; i<Rouns; i++)
	{
		lshift(pk, b[i]);
		des_pc2(pk, skr[i]);
	}

	return 0;
}

//  IN: 56b/64b-key, sub key ring pointer
//  op: 
// OUT: 0 on ok
int DES_set_key(DES_Context* ctx, unsigned char key[8])
{
	memcpy(key, ctx->pk, 8);
	memset(key, 0, 8);

	des_gen_subkeyring(&(ctx->pk), &(ctx->skr));
	
	return 0;
}

int DES_new_session(DES_Context* ctx)
{
	memset(ctx, 0, sizeof(DES_Context));
	return 0;
}

int DES_close_session(DES_Context* ctx)
{
	memset(ctx, 0, sizeof(DES_Context));
	return 0;
}

int DES_enc_block(DES_Context* ctx, ABlock in, ABlock out, int mode)
{
	if (mode==ENC)
	{
		des_ip();
		//des_dec_16r(ctx, in, out);
		des_ipr();		
		return 0;
	}
	else if (mode==DEC)
	{
        des_ipr();
		//des_dec_16r(ctx, in, out);
		des_ip();
		return 0;
	}	
	return -1;
}








main()
{
	unsigned char plaintext[8] = {"plaintxt"};
	unsigned char key[8] = {"password"};
	unsigned char ciphertxt[8] = {0};
	unsigned char plaintxt2[8] = {0};

	DES_Context ctx;

	DES_new_session(&ctx);
    DES_set_key(&ctx, key);
	DES_enc_block(&ctx, plaintext, ciphertxt, ENC);
	DES_enc_block(&ctx, ciphertxt, plaintxt2, DEC);
	DES_close_session(&ctx);
	
	if (memcmp(plaintext, plaintxt2, 8)==0)
		puts("ok");
	else
		puts("err");

	return 0;
}

