/*
* sslt.c  -- ssl test functions(mainly socket related),
*			 const parameters etc.
*
*		ready for all OSs in mind
*		
*		Linden, 04/29 2000
*				0:48 01-5-2
*/

#ifndef __sslt_c_b_
#define __sslt_c_b_


#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
#include <winsock2.h>
#endif

#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/pem.h>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/ssl.h>



typedef unsigned short port_t; /* port type */

#ifndef WIN32
typedef int SOCKET;   /* in fact, SOCKET is a int under unix */
#define Sleep(t) sleep((t+999)/1000);        /* a delay func */
#endif

#define DEFAULT_SSL_HOST_EXT	"0.0.0.0"
#define DEFAULT_SSL_HOST_LPBK	"127.0.0.1"
#define DEFAULT_SSL_PORT		4430

#define CIPHERS		"DES-CBC3-SHA:IDEA-CBC-SHA:EXP-RC4-MD5"
#define	SERVER_CERT	"../certs/server.pem"
#define	CLIENT_CERT	"../certs/client.pem"
#define	CA_CERT		"../certs/root.pem"
#define	CRL_FILE	"../certs/ca.crl"

/* being a server, wait for client to connect */
SOCKET wait_connect(char* ips, port_t port);

/* being a client, try to connect to a waiting server */
SOCKET active_connect(char* ips, port_t port);


SOCKET wait_connect(char* ips, port_t port)
{
	static SOCKET listening = 0;
	SOCKET anews = 0;
	int err = 0;
	struct sockaddr_in addr;

	do {
	
		if (!listening)
		{
#ifdef WIN32
			/* windows socket startup */
			WSADATA	WSAData;
			if (WSAStartup((WORD)0x0101, &WSAData))
			{	err = -10;
				break;
			}			
#endif
			/* a new socket is up */
			listening = socket(AF_INET, SOCK_STREAM, 0);
			if (!listening)
			{	err = -20;
				break;
			}
			
			addr.sin_family = AF_INET;
			addr.sin_port = htons(port);
			addr.sin_addr.s_addr = inet_addr(ips);

			if (bind(listening, (struct sockaddr*)&addr, sizeof(struct sockaddr)))
			{
				int e = WSAGetLastError();
				err = -30;
				break;
			}

			if (listen(listening, 5))
			{	err = -40;
				break;
			}
		}

		anews = accept(listening, NULL, 0);
		if (!anews)
		{	err = -50;
			break;
		}

	} while (0);

	if (err)
	{
		printf("server socket error %1d\n", err);
		return 0;
	}
	
	return anews;
}

SOCKET active_connect(char* ips, port_t port)
{
	int err = 0;
	SOCKET a;
	struct sockaddr_in addr;

	do {

#ifdef WIN32
		static int init = 0;
		WSADATA	WSAData;
		if (!init)
		{
			if (WSAStartup((WORD)0x0101, &WSAData))
			{	err = -10;
				break;
			}			
		}
#endif
		
		a = socket(AF_INET, SOCK_STREAM, 0);
		if (!a)
		{	err = -20;
			break;
		}

		addr.sin_family = AF_INET;
		addr.sin_port = htons(port);
		addr.sin_addr.s_addr = inet_addr(ips);

		if (connect(a, (struct sockaddr *)&addr, sizeof(struct sockaddr)))
		{	err = -30;
			break;
		}

	} while (0);

	if (err)
	{
		printf("\nclient socket error %1d\n", err);
		return 0;
	}
	
	return a;
}


#ifdef __cplusplus
}
#endif

#endif